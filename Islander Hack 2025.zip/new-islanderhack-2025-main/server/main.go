package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"net/http"
	"os"
	"strings"

	"github.com/joho/godotenv"
)

type AvoidPolygons struct {
	Type        string          `json:"type"`
	Coordinates [][][][]float64 `json:"coordinates"`
}

// --- ORS options/payload ---

type Options struct {
	AvoidPolygons *AvoidPolygons `json:"avoid_polygons,omitempty"`
}

type Payload struct {
	Coordinates [][]float64 `json:"coordinates"`
	Radiuses    []float64   `json:"radiuses,omitempty"`
	Options     *Options    `json:"options,omitempty"`
}

type requestPayload struct {
	Coordinates   [][]float64       `json:"coordinates"`
	AvoidPolygons []json.RawMessage `json:"avoid_polygons"`
}

type orsErrorResponse struct {
	Error struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

const (
	orsMaxAvoidExtentMeters = 20000.0
	orsSplitTargetMeters    = 10000.0
	orsSnapRadiusMeters     = 2000.0
)

func parseCoordinateField(raw json.RawMessage) ([][][]float64, error) {
	if len(raw) == 0 {
		return nil, fmt.Errorf("empty coordinate payload")
	}

	var polygon [][][]float64
	if err := json.Unmarshal(raw, &polygon); err == nil && len(polygon) > 0 {
		return polygon, nil
	}

	var ring [][]float64
	if err := json.Unmarshal(raw, &ring); err == nil && len(ring) > 0 {
		return [][][]float64{ring}, nil
	}

	var coordsStr string
	if err := json.Unmarshal(raw, &coordsStr); err != nil {
		return nil, fmt.Errorf("could not decode coordinates: %w", err)
	}

	coordsStr = strings.TrimSpace(coordsStr)
	if coordsStr == "" {
		return nil, fmt.Errorf("empty coordinates string")
	}

	if err := json.Unmarshal([]byte(coordsStr), &polygon); err == nil && len(polygon) > 0 {
		return polygon, nil
	}

	if err := json.Unmarshal([]byte(coordsStr), &ring); err == nil && len(ring) > 0 {
		return [][][]float64{ring}, nil
	}

	return nil, fmt.Errorf("unable to parse coordinates payload")
}

func buildAvoidPolygonCoords(rawList []json.RawMessage) [][][][]float64 {
	multi := make([][][][]float64, 0, len(rawList))

	for _, raw := range rawList {
		var obj map[string]json.RawMessage
		if err := json.Unmarshal(raw, &obj); err != nil {
			log.Printf("avoid_polygons: skipping invalid entry: %v", err)
			continue
		}

		coordsRaw, ok := obj["coordinates"]
		if !ok {
			log.Printf("avoid_polygons: entry missing coordinates field")
			continue
		}

		coords, err := parseCoordinateField(coordsRaw)
		if err != nil {
			log.Printf("avoid_polygons: unable to parse coordinates: %v", err)
			continue
		}

		compliant := ensureORSCompliantPolygons(coords)
		if len(compliant) == 0 {
			log.Printf("avoid_polygons: dropping polygon that could not be reduced to compliant cells")
			continue
		}

		multi = append(multi, compliant...)
	}

	return multi
}

func ensureORSCompliantPolygons(coords [][][]float64) [][][][]float64 {
	if len(coords) == 0 || len(coords[0]) == 0 {
		return nil
	}

	width, height := polygonExtentMeters(coords[0])
	if width <= orsMaxAvoidExtentMeters && height <= orsMaxAvoidExtentMeters {
		return [][][][]float64{coords}
	}

	log.Printf("avoid_polygons: polygon extent %.1fm x %.1fm exceeds ORS max; skipping polygon", width, height)
	return nil
}

func polygonExtentMeters(ring [][]float64) (float64, float64) {
	if len(ring) == 0 {
		return 0, 0
	}

	minLon, maxLon, minLat, maxLat := ringBounds(ring)
	midLat := (minLat + maxLat) / 2
	midLon := (minLon + maxLon) / 2

	width := haversineDistance(midLat, minLon, midLat, maxLon)
	height := haversineDistance(minLat, midLon, maxLat, midLon)

	return width, height
}

func ringBounds(ring [][]float64) (minLon, maxLon, minLat, maxLat float64) {
	minLon = math.Inf(1)
	maxLon = math.Inf(-1)
	minLat = math.Inf(1)
	maxLat = math.Inf(-1)

	for _, coord := range ring {
		if len(coord) < 2 {
			continue
		}
		lon, lat := coord[0], coord[1]
		if lon < minLon {
			minLon = lon
		}
		if lon > maxLon {
			maxLon = lon
		}
		if lat < minLat {
			minLat = lat
		}
		if lat > maxLat {
			maxLat = lat
		}
	}

	return
}

func splitPolygonBoundingBox(ring [][]float64, width, height float64) [][][][]float64 {
	return splitPolygonBoundingBoxWithTarget(ring, width, height, orsSplitTargetMeters)
}

func splitPolygonBoundingBoxWithTarget(ring [][]float64, width, height, targetMeters float64) [][][][]float64 {
	minLon, maxLon, minLat, maxLat := ringBounds(ring)
	if !isFinite(minLon) || !isFinite(maxLon) || !isFinite(minLat) || !isFinite(maxLat) {
		return nil
	}

	if minLon == maxLon && minLat == maxLat {
		return nil
	}

	if targetMeters <= 0 {
		targetMeters = orsSplitTargetMeters
	}

	lonCells := int(math.Ceil(width / targetMeters))
	if lonCells < 1 {
		lonCells = 1
	}
	latCells := int(math.Ceil(height / targetMeters))
	if latCells < 1 {
		latCells = 1
	}

	lonSpan := maxLon - minLon
	latSpan := maxLat - minLat

	results := make([][][][]float64, 0, lonCells*latCells)
	epsilon := 1e-12
	needRefine := false

outer:
	for latIdx := 0; latIdx < latCells; latIdx++ {
		latStart := minLat
		if latSpan > epsilon {
			latStart += (float64(latIdx) / float64(latCells)) * latSpan
		}
		latEnd := maxLat
		if latSpan > epsilon {
			latEnd = minLat + (float64(latIdx+1)/float64(latCells))*latSpan
		}

		for lonIdx := 0; lonIdx < lonCells; lonIdx++ {
			lonStart := minLon
			if lonSpan > epsilon {
				lonStart += (float64(lonIdx) / float64(lonCells)) * lonSpan
			}
			lonEnd := maxLon
			if lonSpan > epsilon {
				lonEnd = minLon + (float64(lonIdx+1)/float64(lonCells))*lonSpan
			}

			if math.Abs(lonEnd-lonStart) < epsilon || math.Abs(latEnd-latStart) < epsilon {
				continue
			}

			cell := [][][]float64{{
				{lonStart, latStart},
				{lonEnd, latStart},
				{lonEnd, latEnd},
				{lonStart, latEnd},
				{lonStart, latStart},
			}}

			cellWidth, cellHeight := polygonExtentMeters(cell[0])
			if cellWidth > orsMaxAvoidExtentMeters || cellHeight > orsMaxAvoidExtentMeters {
				needRefine = true
				break outer
			}

			results = append(results, cell)
		}
	}

	if needRefine {
		if targetMeters <= 500 {
			log.Printf("avoid_polygons: unable to reduce polygon below ORS limits even with %.1fm cells", targetMeters)
			return nil
		}
		return splitPolygonBoundingBoxWithTarget(ring, width, height, targetMeters/2)
	}

	return results
}

func haversineDistance(lat1, lon1, lat2, lon2 float64) float64 {
	const earthRadiusMeters = 6371000.0
	lat1Rad := lat1 * math.Pi / 180
	lat2Rad := lat2 * math.Pi / 180
	deltaLat := (lat2 - lat1) * math.Pi / 180
	deltaLon := (lon2 - lon1) * math.Pi / 180

	sinLat := math.Sin(deltaLat / 2)
	sinLon := math.Sin(deltaLon / 2)

	a := sinLat*sinLat + math.Cos(lat1Rad)*math.Cos(lat2Rad)*sinLon*sinLon
	c := 2 * math.Atan2(math.Sqrt(a), math.Sqrt(1-a))

	return earthRadiusMeters * c
}

func isFinite(v float64) bool {
	return !math.IsNaN(v) && !math.IsInf(v, 0)
}

// --- Main handler ---
func calculateDirections(w http.ResponseWriter, req *http.Request) {
	// --- CORS setup ---
	w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Accept, Authorization")

	if req.Method == http.MethodOptions {
		w.WriteHeader(http.StatusOK)
		return
	}

	if req.Method != http.MethodPost {
		http.Error(w, "Only POST requests allowed", http.StatusMethodNotAllowed)
		return
	}

	defer req.Body.Close()

	// --- Parse frontend JSON ---
	var incoming requestPayload
	if err := json.NewDecoder(req.Body).Decode(&incoming); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		fmt.Println("❌ JSON decode error:", err)
		return
	}

	avoidPolygons := buildAvoidPolygonCoords(incoming.AvoidPolygons)

	payload := Payload{
		Coordinates: incoming.Coordinates,
	}

	if len(incoming.Coordinates) > 0 {
		radiuses := make([]float64, len(incoming.Coordinates))
		for i := range radiuses {
			radiuses[i] = orsSnapRadiusMeters
		}
		payload.Radiuses = radiuses
	}

	if len(avoidPolygons) > 0 {
		payload.Options = &Options{
			AvoidPolygons: &AvoidPolygons{
				Type:        "MultiPolygon",
				Coordinates: avoidPolygons,
			},
		}
	}

	respBody, statusCode, statusText, err := callORS(payload)
	if err != nil {
		http.Error(w, "Error contacting ORS", http.StatusBadGateway)
		log.Printf("❌ ORS request error: %v", err)
		return
	}

	finalBody := respBody
	finalStatusCode := statusCode
	finalStatusText := statusText

	if statusCode >= http.StatusBadRequest {
		var orsErr orsErrorResponse
		if err := json.Unmarshal(respBody, &orsErr); err == nil && orsErr.Error.Code == 2010 && len(payload.Coordinates) > 0 {
			log.Printf("ORS code 2010: retrying with unlimited radiuses for %d coordinates", len(payload.Coordinates))
			fallbackPayload := payload
			fallbackRadiuses := make([]float64, len(payload.Coordinates))
			for i := range fallbackRadiuses {
				fallbackRadiuses[i] = -1
			}
			fallbackPayload.Radiuses = fallbackRadiuses

			respBody, statusCode, statusText, err = callORS(fallbackPayload)
			if err != nil {
				http.Error(w, "Error contacting ORS", http.StatusBadGateway)
				log.Printf("❌ ORS fallback request error: %v", err)
				return
			}

			finalBody = respBody
			finalStatusCode = statusCode
			finalStatusText = statusText
		}
	}

	fmt.Println("✅ ORS status:", finalStatusText)
	fmt.Println("ORS response:", string(finalBody))

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(finalStatusCode)
	w.Write(finalBody)
}

func serveHeatmapData(w http.ResponseWriter, req *http.Request) {
	// Allow CORS
	w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Accept, Authorization")
	w.Header().Set("Vary", "Origin, Access-Control-Request-Method, Access-Control-Request-Headers, Accept-Encoding")

	if req.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if req.Method != "GET" && req.Method != "HEAD" {
		http.Error(w, "This endpoint only accepts GET or HEAD requests", http.StatusMethodNotAllowed)
		return
	}

	const primaryPath = "./data/heatmap_data.json"
	const fallbackPath = "../public/heatmap_data.json"

	openHeatmap := func() (*os.File, os.FileInfo, string, error) {
		candidates := []string{primaryPath, fallbackPath}
		for _, path := range candidates {
			file, err := os.Open(path)
			if err != nil {
				if os.IsNotExist(err) {
					continue
				}
				log.Printf("heatmap: unable to open %s: %v", path, err)
				continue
			}

			stat, err := file.Stat()
			if err != nil {
				log.Printf("heatmap: stat failed for %s: %v", path, err)
				file.Close()
				continue
			}
			return file, stat, path, nil
		}
		return nil, nil, "", os.ErrNotExist
	}

	file, stat, dataPath, err := openHeatmap()
	if err != nil {
		log.Printf("heatmap: no heatmap data available: %v", err)
		http.Error(w, "Could not open heatmap data file", http.StatusInternalServerError)
		return
	}
	defer file.Close()

	w.Header().Set("Cache-Control", "public, max-age=300")
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Content-Disposition", "inline; filename="+stat.Name())

	if req.Method == "HEAD" {
		http.ServeContent(w, req, stat.Name(), stat.ModTime(), file)
		return
	}

	if acceptsGzip(req.Header.Get("Accept-Encoding")) {
		w.Header().Set("Content-Encoding", "gzip")
		w.Header().Del("Content-Length")

		gz := gzip.NewWriter(w)
		defer func() {
			if err := gz.Close(); err != nil {
				log.Printf("heatmap: gzip close error: %v", err)
			}
		}()

		if _, err := io.CopyBuffer(gz, file, make([]byte, 32*1024)); err != nil {
			log.Printf("heatmap: streaming gzip copy error: %v", err)
		}
		return
	}

	if _, err := file.Seek(0, io.SeekStart); err != nil {
		log.Printf("heatmap: failed to rewind %s: %v", dataPath, err)
		http.Error(w, "Could not stream heatmap data", http.StatusInternalServerError)
		return
	}

	http.ServeContent(w, req, stat.Name(), stat.ModTime(), file)
}

func acceptsGzip(header string) bool {
	if header == "" {
		return false
	}

	header = strings.ToLower(header)
	for _, part := range strings.Split(header, ",") {
		part = strings.TrimSpace(part)
		if !strings.HasPrefix(part, "gzip") {
			continue
		}
		if strings.Contains(part, "q=0") {
			continue
		}
		return true
	}

	return false
}

func callORS(payload Payload) ([]byte, int, string, error) {
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, 0, "", fmt.Errorf("encode ORS payload: %w", err)
	}

	reqORS, err := http.NewRequest(
		http.MethodPost,
		"https://api.openrouteservice.org/v2/directions/driving-car/geojson",
		bytes.NewBuffer(body),
	)
	if err != nil {
		return nil, 0, "", fmt.Errorf("build ORS request: %w", err)
	}

	reqORS.Header.Add("Accept", "application/json, application/geo+json")
	reqORS.Header.Add("Content-Type", "application/json; charset=utf-8")
	reqORS.Header.Add("Authorization", os.Getenv("ORS_KEY"))

	client := &http.Client{}
	log.Printf("Sending ORS request: method=%s url=%s payload=%s", reqORS.Method, reqORS.URL, string(body))
	resp, err := client.Do(reqORS)
	if err != nil {
		return nil, 0, "", fmt.Errorf("ORS request failed: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, 0, "", fmt.Errorf("read ORS response: %w", err)
	}

	log.Printf("Received ORS response: status=%s", resp.Status)
	return respBody, resp.StatusCode, resp.Status, nil
}

func main() {
	godotenv.Load("../.env")
	http.HandleFunc("/directions", calculateDirections)
	http.HandleFunc("/heatmapdata", serveHeatmapData)

	http.ListenAndServe(":8080", nil)
}
