import csv
import sys
import ast
import math
from shapely.geometry import Polygon

csv.field_size_limit(sys.maxsize)

infile = "floodzones.csv"
outfile = "floodzones_heatmap.csv"

# Simulation parameters
num_time_steps = 12
rings_per_time = 4
ring_distance = 0.0005
max_intensity = 1.0
decay_per_ring = 0.15
startup_frames = 2

rows_out = []

# ---------- FEMA Zone weighting ----------
FEMA_WEIGHTS = {
    "V": 1.4, "VE": 1.4,
    "A": 1.2, "AE": 1.2,
    "AO": 1.0, "AH": 1.0,
    "A99": 0.9, "AR": 0.9,
    "X": 0.5, "C": 0.5
}

def get_zone_weight(zone: str) -> float:
    """Return FEMA-based flood severity multiplier."""
    if not zone:
        return 1.0
    zone = zone.upper().strip()
    for key, w in FEMA_WEIGHTS.items():
        if zone.startswith(key):
            return w
    return 1.0


# ---------- helpers ----------
def flatten_coords(obj):
    if isinstance(obj, (list, tuple)):
        if len(obj) == 2 and all(isinstance(v, (int, float)) for v in obj):
            return [[float(obj[0]), float(obj[1])]]
        out = []
        for sub in obj:
            out.extend(flatten_coords(sub))
        return out
    return []


def normalize_coords(coords_raw):
    try:
        coords = ast.literal_eval(coords_raw)
    except Exception:
        return None
    cleaned = flatten_coords(coords)
    if len(cleaned) < 3:
        return None
    if cleaned[0] != cleaned[-1]:
        cleaned.append(cleaned[0])
    return cleaned


def expand_points(center, num_rings, step, base_intensity, decay):
    cx, cy = center
    points = [(cx, cy, base_intensity)]
    for r in range(1, num_rings + 1):
        ring_intensity = max(0, base_intensity - decay * r)
        radius = r * step
        for i in range(12):
            angle = 2 * math.pi * i / 12
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            points.append((x, y, ring_intensity))
    return points


# ---------- main ----------
with open(infile, newline='') as f:
    reader = csv.DictReader(f)
    for row in reader:
        coords = normalize_coords(row["coords"])
        if not coords:
            continue

        poly = Polygon(coords)
        cx, cy = poly.centroid.x, poly.centroid.y

        # FEMA-based weighting factor
        zone_weight = get_zone_weight(row["FLD_ZONE"])

        for t in range(num_time_steps):
            if t < startup_frames:
                base_intensity = 0.0
            else:
                progress = (t - startup_frames) / (num_time_steps - 1 - startup_frames)
                base_intensity = (progress ** 2.0) * max_intensity

            # apply FEMA weight (stronger or weaker zones)
            weighted_intensity = base_intensity * zone_weight

            points = expand_points(
                (cx, cy),
                rings_per_time + t,
                ring_distance,
                weighted_intensity,
                decay_per_ring
            )

            for lon, lat, inten in points:
                rows_out.append({
                    "FLD_AR_ID": row["FLD_AR_ID"],
                    "FLD_ZONE": row["FLD_ZONE"],
                    "time": t,
                    "longitude": lon,
                    "latitude": lat,
                    "intensity": round(inten, 4)
                })

with open(outfile, "w", newline="") as f:
    fieldnames = ["FLD_AR_ID", "FLD_ZONE", "time", "longitude", "latitude", "intensity"]
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows_out)

print(f"✅ FEMA-weighted flood-progression heatmap written to {outfile} with {len(rows_out)} points.")
