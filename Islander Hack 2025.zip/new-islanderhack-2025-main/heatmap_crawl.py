import ast
import csv
import math
import random
import sys
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple

from shapely.geometry import Point, Polygon


csv.field_size_limit(sys.maxsize)

INFILE = "floodzones.csv"
OUTFILE = "floodzones_heatmap.csv"

# Simulation parameters tuned for a smoother, organic flood progression
NUM_TIME_STEPS = 100
STARTUP_FRAMES = 3
MAX_INTENSITY = 1.0

SAMPLES_PER_POLYGON = 120
HALO_SAMPLES = 36
MAX_EXPANSION_FACTOR = 1.25  # allows the wave to extend beyond the polygon
RADIAL_SOFTNESS = 0.18       # controls how soft the wavefront transition is
RADIUS_JITTER = 0.08         # per-point jitter to avoid perfect concentric shells

# FEMA severity weights
FEMA_WEIGHTS = {
    "V": 1.4,
    "VE": 1.4,
    "A": 1.2,
    "AE": 1.2,
    "AO": 1.0,
    "AH": 1.0,
    "A99": 0.9,
    "AR": 0.9,
    "X": 0.5,
    "C": 0.5,
}


@dataclass(frozen=True)
class CrawlConfig:
    num_time_steps: int = NUM_TIME_STEPS
    startup_frames: int = STARTUP_FRAMES
    max_intensity: float = MAX_INTENSITY
    samples_per_polygon: int = SAMPLES_PER_POLYGON
    halo_samples: int = HALO_SAMPLES
    max_expansion_factor: float = MAX_EXPANSION_FACTOR
    radial_softness: float = RADIAL_SOFTNESS
    radius_jitter: float = RADIUS_JITTER


@dataclass(frozen=True)
class SamplePoint:
    lon: float
    lat: float
    radius_norm: float
    jitter: float
    kind: str  # "interior" or "halo"


def get_zone_weight(zone: Optional[str]) -> float:
    if not zone:
        return 1.0
    zone = zone.upper().strip()
    for key, weight in FEMA_WEIGHTS.items():
        if zone.startswith(key):
            return weight
    return 1.0


def flatten_coords(obj: Sequence) -> List[Tuple[float, float]]:
    if isinstance(obj, (list, tuple)):
        if len(obj) == 2 and all(isinstance(v, (int, float)) for v in obj):
            return [(float(obj[0]), float(obj[1]))]
        points: List[Tuple[float, float]] = []
        for sub in obj:
            points.extend(flatten_coords(sub))
        return points
    return []


def normalize_coords(coords_raw: str) -> Optional[List[Tuple[float, float]]]:
    try:
        coords_obj = ast.literal_eval(coords_raw)
    except Exception:
        return None
    cleaned = flatten_coords(coords_obj)
    if len(cleaned) < 3:
        return None
    if cleaned[0] != cleaned[-1]:
        cleaned.append(cleaned[0])
    return cleaned


def smooth_activation(progress: float, radius_norm: float, softness: float) -> float:
    offset = progress - radius_norm
    if offset <= -softness:
        return 0.0
    if offset >= softness:
        return 1.0
    x = (offset + softness) / (2 * softness)
    return x * x * (3 - 2 * x)  # smoothstep interpolation


def compute_max_radius(poly: Polygon, centroid: Point) -> float:
    return max(centroid.distance(Point(x, y)) for x, y in poly.exterior.coords)


def prepare_samples(poly: Polygon, seed_base: int, config: CrawlConfig) -> Tuple[List[SamplePoint], Point, float]:
    centroid = poly.centroid
    if centroid.is_empty:
        centroid = Point(0.0, 0.0)
    max_radius = compute_max_radius(poly, centroid)
    if max_radius == 0.0:
        max_radius = 1.0

    minx, miny, maxx, maxy = poly.bounds
    rng = random.Random(seed_base)
    samples: List[SamplePoint] = []

    # Interior samples via rejection sampling
    attempt_limit = config.samples_per_polygon * 20
    attempts = 0
    while len(samples) < config.samples_per_polygon and attempts < attempt_limit:
        attempts += 1
        px = rng.uniform(minx, maxx)
        py = rng.uniform(miny, maxy)
        point = Point(px, py)
        if not poly.covers(point):
            continue
        dist = centroid.distance(point)
        radius_norm = dist / max_radius
        jitter = (rng.random() - 0.5) * config.radius_jitter
        samples.append(SamplePoint(px, py, radius_norm, jitter, "interior"))

    # Halo samples to allow the wave to push beyond the polygon
    halo_rng = random.Random(seed_base ^ 0x9E3779B9)
    for idx in range(config.halo_samples):
        angle = 2.0 * math.pi * (idx / max(1, config.halo_samples))
        angle += (halo_rng.random() - 0.5) * 0.3  # slight angular jitter
        radius_factor = 1.02 + halo_rng.random() * (config.max_expansion_factor - 1.02)
        px = centroid.x + max_radius * radius_factor * math.cos(angle)
        py = centroid.y + max_radius * radius_factor * math.sin(angle)
        radius_norm = radius_factor
        jitter = (halo_rng.random() - 0.5) * config.radius_jitter
        samples.append(SamplePoint(px, py, radius_norm, jitter, "halo"))

    return samples, centroid, max_radius


def generate_points_for_time(
    samples: Sequence[SamplePoint],
    progress: float,
    weighted_intensity: float,
    config: CrawlConfig,
) -> Iterable[Tuple[float, float, float]]:
    for sample in samples:
        effective_radius = max(0.0, sample.radius_norm + sample.jitter)
        activation = smooth_activation(progress, effective_radius, config.radial_softness)
        if activation <= 0.0:
            continue

        if sample.kind == "halo":
            # halo stays dimmer and only lights up near the wavefront
            intensity = weighted_intensity * activation * 0.6
        else:
            # interior gradually fills in after the wavefront passes
            interior_factor = 0.35 + 0.65 * activation
            intensity = weighted_intensity * interior_factor

        if intensity <= 0.0:
            continue

        yield sample.lon, sample.lat, min(config.max_intensity, intensity)


def generate_rows(infile: str, config: CrawlConfig) -> List[dict]:
    rows_out: List[dict] = []

    with open(infile, newline="") as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            coords = normalize_coords(row["coords"])
            if not coords:
                continue

            poly = Polygon(coords)
            if poly.is_empty:
                continue

            simplified = poly.simplify(0.0002, preserve_topology=True)
            if simplified.is_empty:
                simplified = poly

            zone_weight = get_zone_weight(row["FLD_ZONE"])
            seed_base = abs(hash(row["FLD_AR_ID"])) & 0xFFFFFFFF
            samples, centroid, _ = prepare_samples(simplified, seed_base, config)

            for t in range(config.num_time_steps):
                if t < config.startup_frames:
                    base_intensity = 0.0
                    progress = 0.0
                else:
                    span = max(1, config.num_time_steps - config.startup_frames)
                    progress = (t - config.startup_frames) / span
                    base_intensity = (1 - math.cos(progress * math.pi)) * 0.5 * config.max_intensity

                weighted_intensity = base_intensity * zone_weight
                if weighted_intensity <= 0.0:
                    continue

                for lon, lat, intensity in generate_points_for_time(
                    samples,
                    progress,
                    weighted_intensity,
                    config,
                ):
                    rows_out.append(
                        {
                            "FLD_AR_ID": row["FLD_AR_ID"],
                            "FLD_ZONE": row["FLD_ZONE"],
                            "time": t,
                            "longitude": lon,
                            "latitude": lat,
                            "intensity": round(intensity, 4),
                        }
                    )

    return rows_out


def write_rows(outfile: str, rows: Sequence[dict]) -> None:
    fieldnames = ["FLD_AR_ID", "FLD_ZONE", "time", "longitude", "latitude", "intensity"]
    with open(outfile, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    config = CrawlConfig()
    rows = generate_rows(INFILE, config)
    write_rows(OUTFILE, rows)
    print(f"✅ Crawling flood heatmap written to {OUTFILE} with {len(rows)} points.")


if __name__ == "__main__":
    main()
