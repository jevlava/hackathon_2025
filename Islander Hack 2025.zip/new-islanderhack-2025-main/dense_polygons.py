import argparse
import csv
import json
from dataclasses import dataclass
from typing import Iterable, List, Sequence

import pandas as pd
from shapely.geometry import Point, Polygon
from shapely.ops import unary_union

DEFAULT_INFILE = "floodzones_heatmap.csv"
DEFAULT_OUTFILE = "dense_polygons.csv"


@dataclass(frozen=True)
class ExtractionConfig:
    intensity_quantile: float = 0.9
    buffer_radius: float = 0.0012
    simplify_tolerance: float = 0.0001
    min_points: int = 50


def load_heatmap(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    required = {"time", "longitude", "latitude", "intensity"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Input file is missing required columns: {missing}")
    return df


def select_densest_frame(df: pd.DataFrame) -> int:
    totals = df.groupby("time")["intensity"].sum()
    if totals.empty:
        raise ValueError("No time slices found in input data.")
    densest_time = int(totals.idxmax())
    return densest_time


def filter_hot_points(frame: pd.DataFrame, config: ExtractionConfig) -> pd.DataFrame:
    if frame.empty:
        return frame

    threshold = frame["intensity"].quantile(config.intensity_quantile)
    hot = frame[frame["intensity"] >= threshold].copy()
    if hot.empty:
        hot = frame.nlargest(config.min_points, "intensity").copy()
    elif len(hot) < config.min_points:
        extra = frame.nlargest(config.min_points, "intensity").copy()
        hot = pd.concat([hot, extra]).drop_duplicates()

    return hot


def build_polygons(points: pd.DataFrame, config: ExtractionConfig) -> List[Polygon]:
    if points.empty:
        return []

    blobs = [
        Point(row.longitude, row.latitude).buffer(config.buffer_radius)
        for row in points.itertuples()
    ]
    merged = unary_union(blobs)

    if merged.is_empty:
        return []
    if merged.geom_type == "Polygon":
        geometries: Iterable[Polygon] = [merged]
    elif merged.geom_type == "MultiPolygon":
        geometries = merged.geoms
    else:
        geometries = [
            geom for geom in merged.geoms if isinstance(geom, Polygon)
        ]

    simplified = [
        geom.simplify(config.simplify_tolerance, preserve_topology=True)
        for geom in geometries
        if isinstance(geom, Polygon)
    ]
    return [poly for poly in simplified if not poly.is_empty]


def polygons_to_rows(polygons: Sequence[Polygon], time_slice: int, config: ExtractionConfig) -> List[dict]:
    rows = []
    for idx, poly in enumerate(polygons, start=1):
        coords = list(poly.exterior.coords)
        rows.append(
            {
                "polygon_id": idx,
                "time": time_slice,
                "intensity_quantile": config.intensity_quantile,
                "buffer_radius": config.buffer_radius,
                "simplify_tolerance": config.simplify_tolerance,
                "area": poly.area,
                "coordinates": json.dumps(coords),
            }
        )
    return rows


def write_rows(path: str, rows: Sequence[dict]) -> None:
    fieldnames = [
        "polygon_id",
        "time",
        "intensity_quantile",
        "buffer_radius",
        "simplify_tolerance",
        "area",
        "coordinates",
    ]
    with open(path, "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extract dense polygons from the densest heatmap frame."
    )
    parser.add_argument(
        "--input",
        default=DEFAULT_INFILE,
        help=f"Path to heatmap CSV (default: {DEFAULT_INFILE})",
    )
    parser.add_argument(
        "--output",
        default=DEFAULT_OUTFILE,
        help=f"Path for output polygons CSV (default: {DEFAULT_OUTFILE})",
    )
    parser.add_argument(
        "--quantile",
        type=float,
        default=ExtractionConfig.intensity_quantile,
        help="Intensity quantile (0-1) defining 'dense' points (default: 0.9).",
    )
    parser.add_argument(
        "--buffer",
        type=float,
        default=ExtractionConfig.buffer_radius,
        help="Buffer radius (in degrees) used to merge nearby hot points (default: 0.0012).",
    )
    parser.add_argument(
        "--simplify",
        type=float,
        default=ExtractionConfig.simplify_tolerance,
        help="Simplification tolerance for output polygons (default: 0.0001).",
    )
    parser.add_argument(
        "--min-points",
        type=int,
        default=ExtractionConfig.min_points,
        help="Minimum number of points to retain for clustering (default: 50).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = ExtractionConfig(
        intensity_quantile=args.quantile,
        buffer_radius=args.buffer,
        simplify_tolerance=args.simplify,
        min_points=args.min_points,
    )

    df = load_heatmap(args.input)
    densest_time = select_densest_frame(df)
    densest_frame = df[df["time"] == densest_time].copy()
    hot_points = filter_hot_points(densest_frame, config)
    polygons = build_polygons(hot_points, config)
    rows = polygons_to_rows(polygons, densest_time, config)

    write_rows(args.output, rows)
    print(
        f"✅ Wrote {len(rows)} dense polygons for time={densest_time} to {args.output}"
    )


if __name__ == "__main__":
    main()
