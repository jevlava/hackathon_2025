import './styles/app.css'
import MapView, { Source, Layer } from 'react-map-gl/maplibre';
import 'maplibre-gl/dist/maplibre-gl.css';
import { useEffect, useState, useRef, useMemo } from 'react';
import Autocomplete from "react-google-autocomplete"
import Papa from "papaparse"

const avoidPolygons = {
  type: "Polygon",
  coordinates: [
    [
      [-97.36237438468169, 27.723077164091112],
      [-97.36160850678905, 27.722346544574236],
      [-97.3624189989279, 27.720931366719352],
      [-97.36172004240449, 27.72100377161359]
    ]
  ]
};

const geojson = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [-97.36265, 27.72294]
      },
      properties: {title: '915 Front Street, San Francisco, California'}
    }
  ]
};

const layerStyle = {
  id: 'point',
  type: 'circle',
  paint: {
    'circle-radius': 10,
    'circle-color': '#007cbf'
  }
};

const pathStyle = {
  id: 'my-line',        // unique id for this layer
  type: 'line',
  source: 'lines',      // the id of your <Source>
  layout: {
    'line-join': 'round',    // how line segments join
    'line-cap': 'round'      // end of the line style
  },
  paint: {
    'line-color': '#FF0000', // red line
    'line-width': 4,         // thickness in pixels
    'line-opacity': 0.8,     // optional transparency
    // 'line-dasharray': [2, 4] // optional dash pattern: 2px dash, 4px gap
  }
}

const EMPTY_HEATMAP = {
  type: "FeatureCollection",
  features: []
};

const heatLayer = {
  id: "heatmap",
  type: "heatmap",
  paint: {
    "heatmap-weight": [
      "interpolate",
      ["linear"],
      ["coalesce", ["get", "weight"], 0],
      0, 0,
      0.02, 0.12,
      0.15, 0.45,
      0.6, 0.82,
      1, 1
    ],
    "heatmap-intensity": [
      "interpolate",
      ["linear"],
      ["zoom"],
      8, 0.7,
      11, 1.25,
      13, 1.9,
      15, 2.4
    ],
    "heatmap-radius": [
      "interpolate",
      ["linear"],
      ["zoom"],
      7, 16,
      9, 24,
      11, 34,
      13, 44,
      15, 56
    ],
    "heatmap-opacity": [
      "interpolate",
      ["linear"],
      ["zoom"],
      8, 0.7,
      11, 0.85,
      15, 0.96
    ],
    "heatmap-color": [
      "interpolate",
      ["linear"],
      ["heatmap-density"],
      0, "rgba(0, 0, 255, 0)",
      0.2, "rgba(0, 70, 200, 0.6)",
      0.4, "rgba(0, 200, 255, 0.75)",
      0.6, "rgba(80, 255, 120, 0.85)",
      0.8, "rgba(255, 230, 30, 0.92)",
      1, "rgba(255, 60, 0, 0.97)"
    ]
  }
};

const avoidPolygonFillLayer = {
  id: "avoid-polygons-fill",
  type: "fill",
  paint: {
    "fill-color": "rgba(230, 30, 30, 0.28)",
    "fill-opacity": 0.35
  }
};

const avoidPolygonOutlineLayer = {
  id: "avoid-polygons-outline",
  type: "line",
  paint: {
    "line-color": "#d52a1d",
    "line-width": 2
  }
};

function App() {
  const key = `https://api.maptiler.com/maps/streets/style.json?key=${process.env.REACT_APP_MAPTILER_KEY}`
  let [coords, setCoords] = useState([])
  let [jsonGeo, setJsonGeo] = useState()
  let [pathGeo, setPathGeo] = useState()
  let [responseData, setResponseData] = useState([])
  let [path, setPath] = useState([])
  const inputRef = useRef(null)

  const [frames, setFrames] = useState([]);
  const [heatData, setHeatData] = useState(EMPTY_HEATMAP);
  const [timeKeys, setTimeKeys] = useState([]);
  const [timeIndex, setTimeIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [playSpeed, setPlaySpeed] = useState(800);
  const playbackRef = useRef(null);
  const [lat, setLat] = useState(27.78)
  const [lng, setLng] = useState(-97.4)

  const [avoidPayload, setAvoidPayload] = useState([])

  const avoidPolygonsGeoJson = useMemo(() => {
    const features = avoidPayload.map((entry, index) => {
      const rawCoordinates = entry?.coordinates;
      if (!rawCoordinates) {
        return null;
      }

      let parsed = rawCoordinates;
      if (typeof parsed === "string") {
        try {
          parsed = JSON.parse(parsed);
        } catch (err) {
          console.warn("avoid_polygons: unable to parse coordinate string", err);
          return null;
        }
      }

      if (!Array.isArray(parsed)) {
        return null;
      }

      const ring = parsed
        .map((coordinate) => {
          if (!Array.isArray(coordinate) || coordinate.length < 2) {
            return null;
          }

          const lon = Number(coordinate[0]);
          const lat = Number(coordinate[1]);

          if (!Number.isFinite(lon) || !Number.isFinite(lat)) {
            return null;
          }

          return [lon, lat];
        })
        .filter(Boolean);

      if (ring.length < 3) {
        return null;
      }

      const [firstLon, firstLat] = ring[0];
      const [lastLon, lastLat] = ring[ring.length - 1];

      if (Math.abs(firstLon - lastLon) > 1e-9 || Math.abs(firstLat - lastLat) > 1e-9) {
        ring.push([firstLon, firstLat]);
      }

      return {
        type: "Feature",
        geometry: {
          type: "Polygon",
          coordinates: [ring]
        },
        properties: {
          polygon_id: entry?.polygon_id ?? index,
          intensity_quantile: entry?.intensity_quantile ?? null,
          area: entry?.area ?? null
        }
      };
    }).filter(Boolean);

    return {
      type: "FeatureCollection",
      features
    };
  }, [avoidPayload]);

  useEffect(() => {
    async function fetchData(){
      const res = await fetch("/dense_polygons.csv")

      const text = await res.text()
      const parsed = Papa.parse(text, {
        header: true,   // use the first row as keys
        dynamicTyping: true, // auto-convert numbers
        skipEmptyLines: true
      });

      const MAX_AVOID_POLYGONS = 25;

      const trimmed = parsed.data
        .filter(row => row && row.coordinates)
        .sort((a, b) => {
          const intensityDelta = Number(b?.intensity_quantile ?? 0) - Number(a?.intensity_quantile ?? 0);
          if (intensityDelta !== 0) {
            return intensityDelta;
          }
          return Number(b?.area ?? 0) - Number(a?.area ?? 0);
        })
        .slice(0, MAX_AVOID_POLYGONS);

      setAvoidPayload(trimmed)
    }

    fetchData()
  }, [])

  useEffect(() => {
    let cancelled = false;

    const hydrateHeatmap = async () => {
      const publicUrl = process.env.PUBLIC_URL ?? "";
      const candidates = [
        "http://localhost:8080/heatmapdata",
        publicUrl ? `${publicUrl.replace(/\/$/, "")}/heatmap_data.json` : null,
        "/heatmap_data.json"
      ].filter((value, index, array) => typeof value === "string" && value.length > 0 && array.indexOf(value) === index);

      let payload = null;
      let lastError = null;

      for (const url of candidates) {
        try {
          const res = await fetch(url, { headers: { Accept: "application/json" } });
          if (!res.ok) {
            throw new Error(`Heatmap fetch failed: ${res.status}`);
          }

          const data = await res.json();
          if (data && typeof data === "object") {
            payload = data;
            break;
          }
        } catch (err) {
          lastError = err;
          console.warn(`Heatmap request failed for ${url}`, err);
        }
      }

      if (!payload) {
        if (!cancelled) {
          setFrames([]);
          setHeatData(EMPTY_HEATMAP);
          setTimeKeys([]);
          setTimeIndex(0);
          setIsPlaying(false);
        }
        console.error("Failed to load heatmap data", lastError);
        return;
      }

      const points = Array.isArray(payload?.points) ? payload.points : [];

      const providedTimes = Array.isArray(payload?.timeSteps)
        ? payload.timeSteps
            .map((value) => Number(value))
            .filter((value) => Number.isFinite(value))
        : [];

      const grouped = new Map();
      let maxWeight = 0;

      points.forEach((row) => {
        const time = Number(row?.time);
        const longitude = Number(row?.longitude);
        const latitude = Number(row?.latitude);
        const intensityValue = Number(row?.intensity) || 0;
        const samplesValue = Number(row?.samples) || 0;

        if (!Number.isFinite(time) || !Number.isFinite(longitude) || !Number.isFinite(latitude)) {
          return;
        }

        const rawWeight = Math.max(intensityValue, samplesValue, 0);
        maxWeight = Math.max(maxWeight, rawWeight);

        if (!grouped.has(time)) {
          grouped.set(time, []);
        }

        grouped.get(time).push({
          coordinates: [longitude, latitude],
          samples: samplesValue,
          intensity: intensityValue,
          rawWeight
        });
      });

      const candidateTimes = providedTimes.length
        ? providedTimes.concat(Array.from(grouped.keys()))
        : Array.from(grouped.keys());

      const uniqueTimes = [...new Set(candidateTimes.filter((value) => Number.isFinite(value)))].sort((a, b) => a - b);

      if (cancelled) {
        return;
      }

      setTimeKeys(uniqueTimes);

      if (uniqueTimes.length === 0) {
        setFrames([]);
        setHeatData(EMPTY_HEATMAP);
        setTimeIndex(0);
        setIsPlaying(false);
        return;
      }

      const safeMaxWeight = maxWeight > 0 ? maxWeight : 1;

      const preparedFrames = uniqueTimes.map((time) => {
        const entries = grouped.get(time) || [];
        const features = entries.map((entry) => ({
          type: "Feature",
          geometry: {
            type: "Point",
            coordinates: entry.coordinates
          },
          properties: {
            weight: entry.rawWeight > 0 ? Math.pow(entry.rawWeight / safeMaxWeight, 0.45) : 0,
            samples: entry.samples,
            intensity: entry.intensity,
            time
          }
        }));

        return {
          time,
          collection: {
            type: "FeatureCollection",
            features
          }
        };
      });

      if (cancelled) {
        return;
      }

      setFrames(preparedFrames);
      setHeatData(preparedFrames[0]?.collection ?? EMPTY_HEATMAP);
      setTimeIndex(0);
      setIsPlaying(preparedFrames.length > 1);
    };

    hydrateHeatmap();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (timeKeys.length === 0) {
      setTimeIndex(0);
      return;
    }

    setTimeIndex(prev => {
      if (prev >= timeKeys.length) {
        return 0;
      }
      return prev;
    });
  }, [timeKeys.length]);

  useEffect(() => {
    if (!isPlaying || timeKeys.length <= 1) {
      return undefined;
    }

    playbackRef.current = setInterval(() => {
      setTimeIndex(prev => (prev + 1) % timeKeys.length);
    }, playSpeed);

    return () => {
      if (playbackRef.current) {
        clearInterval(playbackRef.current);
        playbackRef.current = null;
      }
    };
  }, [isPlaying, playSpeed, timeKeys]);

  useEffect(() => {
    if (frames.length === 0 || timeKeys.length === 0) {
      setHeatData(EMPTY_HEATMAP);
      return;
    }

    const safeLength = timeKeys.length;
    const normalizedIndex = ((timeIndex % safeLength) + safeLength) % safeLength;
    const nextFrame = frames[normalizedIndex];

    if (!nextFrame) {
      setHeatData(EMPTY_HEATMAP);
      return;
    }

    setHeatData(nextFrame.collection);
  }, [timeIndex, timeKeys, frames]);

  const handleSelectLocation = (place) => {
    let loc = place.geometry.location

    setCoords(prevCoords => [...prevCoords, [loc.lng(), loc.lat()]])

    if(inputRef.current){
      inputRef.current.value = ""
    }

    const changeView = () => {
      mapRef.current.flyTo({
        center: [loc.lng(), loc.lat()],
        zoom: 13,
        speed: 1.2, // animation speed
        curve: 1.4,
      });
  };
    changeView()
  }

  const handleSubmit = async() => {
    // change css first
    const sun = document.querySelector(".sun")
    const moon = document.querySelector(".moon")

    sun.style.animation = "riseAndSet 16s ease-in-out infinite"
    moon.style.animation = "setAndRise 16s ease-in-out infinite"
    
    let res = await fetch("http://localhost:8080/directions", {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': process.env.REACT_APP_MAPTILER_KEY
      },
      body: JSON.stringify({
        coordinates: coords,
        avoid_polygons: avoidPayload
      })
    })      

    let data = await res.json().then((d) => {
      setResponseData(d)
    })
  }

  useEffect(() => {
    console.log(coords)

    const features = coords.map((coord, index) => ({
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: coord
      },
    }))

    setJsonGeo({
      type: 'FeatureCollection',
      features: features
    })
  },[coords])

  useEffect(() => {
    console.log(responseData)
    const w = document.querySelector(".writing")
    if(responseData.length <= 0){
      w.textContent = "Welcome to FES. Please enter an address above."
      return
    }
    
    if(responseData.error != null){
      w.textContent = "We couldn't find a safe route for you. Stay home for now."
    }else{
      w.textContent = "We found a route for you. Please be careful"
    }
    
    const feature = responseData?.features?.[0];
    const geometry = feature?.geometry;

    if (!feature || !geometry) {
      return;
    }

    let lineCoordinates = null;
    if (geometry.type === "LineString" && Array.isArray(geometry.coordinates)) {
      lineCoordinates = geometry.coordinates;
    } else if (geometry.type === "MultiLineString" && Array.isArray(geometry.coordinates)) {
      lineCoordinates = geometry.coordinates.flat().filter(Array.isArray);
    }

    if (!Array.isArray(lineCoordinates) || lineCoordinates.length === 0) {
      return;
    }

    setPath(lineCoordinates);

    const waypoints = feature?.properties?.way_points;
    if (!Array.isArray(waypoints) || waypoints.length === 0) {
      return;
    }

    const snappedPoints = waypoints
      .map((index) => {
        const idx = Number(index);
        if (!Number.isFinite(idx)) {
          return null;
        }
        return lineCoordinates[idx] ?? null;
      })
      .filter((point) => Array.isArray(point) && point.length >= 2);

    if (snappedPoints.length !== waypoints.length) {
      return;
    }

    const epsilon = 1e-7;
    setCoords((prevCoords) => {
      const sameLength = Array.isArray(prevCoords) && prevCoords.length === snappedPoints.length;
      const unchanged =
        sameLength &&
        prevCoords.every((coord, idx) => {
          const next = snappedPoints[idx];
          if (!Array.isArray(coord) || !Array.isArray(next)) {
            return false;
          }
          const lonDelta = Math.abs(Number(coord[0]) - Number(next[0]));
          const latDelta = Math.abs(Number(coord[1]) - Number(next[1]));
          return lonDelta <= epsilon && latDelta <= epsilon;
        });

      return unchanged ? prevCoords : snappedPoints;
    });
  }, [responseData])

  useEffect(() => {
    console.log(path)

    const lineGeoJson = {
      type: "FeatureCollection",
      features: [
        {
          type: "Feature",
          properties: {}, // optional, you can store info like name, color, etc.
          geometry: {
            type: "LineString",
            coordinates: path
          }
        }
      ]
    };

    setPathGeo(lineGeoJson)
  }, [path])

  const sliderMax = timeKeys.length > 0 ? timeKeys.length - 1 : 0;
  const disableControls = timeKeys.length === 0;
  const safeTimeIndex = disableControls ? 0 : ((timeIndex % timeKeys.length) + timeKeys.length) % timeKeys.length;
  const currentTimeLabel = timeKeys.length ? `${safeTimeIndex + 1}/${timeKeys.length}` : "--";
  const handleStep = (direction) => {
    if (timeKeys.length === 0) return;
    setTimeIndex(prev => {
      const next = (prev + direction + timeKeys.length) % timeKeys.length;
      return next;
    });
  };

  const handleSliderChange = (event) => {
    const nextIndex = Number(event.target.value);
    setTimeIndex(nextIndex);
  };

  const handleSpeedChange = (event) => {
    const nextSpeed = Number(event.target.value);
    setPlaySpeed(nextSpeed);
  };

  const mapRef = useRef()

  return (
  <div className="main">
    <div className='leftBox'>
      <img className='tae' src='/tae2.png' />
      <img className='fes' src='fespng.png'/>
      <div className='sun'>
      </div>

      <img className='moon' src='crescentgrey.png'/>
    </div>
    <div className='rightBox'>
      <div className='mapBox'>
       <Autocomplete
        ref={inputRef}
        placeholder="Enter an address here"
        className='autocomplete_box'
      apiKey={process.env.REACT_APP_MAPS_KEY}
      onPlaceSelected={(place) => handleSelectLocation(place)}
        options={{
          types: ["address"],
          componentRestrictions: {country: "us"}
        }}/>
      <div className="submitBox" onClick={handleSubmit}>
      </div>
        <MapView
          ref = {mapRef}
          style={{
          height: "90%",
          width: "90%",
          borderRadius: "30px"
        }}
          initialViewState={{
            longitude: lng,
            latitude: lat,
            zoom: 11
          }}
          mapStyle={key}
        >
        <Source id="my-data" type="geojson" data={jsonGeo}>
            <Layer {...layerStyle} />
        </Source>    
        <Source id="path" type="geojson" data={pathGeo}>
          <Layer {...pathStyle} />
        </Source>
        <Source id="heatmap-source" type="geojson" data={heatData}>
          <Layer {...heatLayer} />
        </Source>
        <Source id="avoid-polygons" type="geojson" data={avoidPolygonsGeoJson}>
          <Layer {...avoidPolygonFillLayer} />
          <Layer {...avoidPolygonOutlineLayer} />
        </Source>
        </MapView>
        <div className="heatmap-control-panel">
          <div className="control-row">
            <button
              className="control-button"
              onClick={() => handleStep(-1)}
              disabled={disableControls}
            >
              {"<<"}
            </button>
            <button
              className="control-button"
              onClick={() => setIsPlaying(prev => !prev)}
              disabled={disableControls}
            >
              {isPlaying ? "||" : ">"}
            </button>
            <button
              className="control-button"
              onClick={() => handleStep(1)}
              disabled={disableControls}
            >
              {">>"}
            </button>
          </div>
          <div className="slider-row">
            <input
              className="heatmap-slider"
              type="range"
              min={0}
              max={sliderMax}
              step={1}
              value={disableControls ? 0 : safeTimeIndex}
              onChange={handleSliderChange}
              disabled={disableControls}
            />
          </div>
        </div>
      </div>
    <div className='textBox'>
      <div className='square'></div>
      <text className='writing'>
        Welcome to Fes. Enter your location and destination <br />
        and we'll find a route for you.
      </text>
    </div>
    </div>
     </div>
  );
}

export default App;
