#!/usr/bin/env python3
"""Clean flood-related CSV sources and emit a JSON payload for the web client.

This script normalizes the heatmap point data and, if available, dense polygon
overlays. It is intended to be run whenever the upstream CSV exports change,
writing the cleaned output to ``public/heatmap_data.json``.
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Set, Tuple


DEFAULT_HEATMAP = Path("floodzones_heatmap.csv")
DEFAULT_POLYGONS = Path("dense_polygons.csv")
DEFAULT_OUTPUT = Path("public/heatmap_data.json")


@dataclass
class Stats:
    count: int = 0
    min_lon: Optional[float] = None
    min_lat: Optional[float] = None
    max_lon: Optional[float] = None
    max_lat: Optional[float] = None

    def update(self, lon: float, lat: float) -> None:
        if self.min_lon is None or lon < self.min_lon:
            self.min_lon = lon
        if self.max_lon is None or lon > self.max_lon:
            self.max_lon = lon
        if self.min_lat is None or lat < self.min_lat:
            self.min_lat = lat
        if self.max_lat is None or lat > self.max_lat:
            self.max_lat = lat
        self.count += 1

    def to_dict(self) -> dict:
        return {
            "count": self.count,
            "lon": {"min": self.min_lon, "max": self.max_lon},
            "lat": {"min": self.min_lat, "max": self.max_lat},
        }


def _to_float(value: str) -> Optional[float]:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: str) -> Optional[int]:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def load_heatmap(path: Path, precision: int, max_points: Optional[int]) -> List[dict]:
    if not path.exists():
        raise FileNotFoundError(f"Heatmap CSV not found: {path}")

    buckets: dict[Tuple[int, float, float], dict] = {}

    with path.open(newline="") as csvfile:
        reader = csv.DictReader(csvfile)
        required = {"time", "longitude", "latitude", "intensity"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Heatmap CSV missing required fields: {sorted(missing)}")

        for row in reader:
            lon = _to_float(row.get("longitude"))
            lat = _to_float(row.get("latitude"))
            intensity = _to_float(row.get("intensity"))
            time_step = _to_int(row.get("time"))
            if None in (lon, lat, intensity, time_step):
                continue
            if not (-180.0 <= lon <= 180.0 and -90.0 <= lat <= 90.0):
                continue
            if intensity < 0:
                continue

            lon_key = round(lon, precision)
            lat_key = round(lat, precision)
            key = (time_step, lon_key, lat_key)
            if key not in buckets:
                buckets[key] = {
                    "sum_intensity": 0.0,
                    "count": 0,
                    "zones": set(),  # type: Set[str]
                    "areas": set(),  # type: Set[str]
                }

            bucket = buckets[key]
            bucket["sum_intensity"] += intensity
            bucket["count"] += 1
            if row.get("FLD_ZONE"):
                bucket["zones"].add(row["FLD_ZONE"])
            if row.get("FLD_AR_ID"):
                bucket["areas"].add(row["FLD_AR_ID"])

    points: List[dict] = []
    for (time_step, lon_key, lat_key), bucket in buckets.items():
        count = bucket["count"] or 1
        avg_intensity = bucket["sum_intensity"] / count
        point = {
            "time": time_step,
            "longitude": lon_key,
            "latitude": lat_key,
            "intensity": round(avg_intensity, 6),
            "samples": count,
        }
        if bucket["zones"]:
            point["fema_zone"] = sorted(bucket["zones"])[0]
        if bucket["areas"]:
            point["fema_area_id"] = sorted(bucket["areas"])[0]

        points.append(point)

    aggregated_count = len(points)
    if max_points and len(points) > max_points:
        per_time: dict[int, List[dict]] = {}
        for point in points:
            per_time.setdefault(point["time"], []).append(point)

        times_sorted = sorted(per_time.keys())
        if times_sorted:
            base_quota = max_points // len(times_sorted)
            remainder = max_points % len(times_sorted)

            selected: List[dict] = []
            overflow: List[Tuple[List[dict], int]] = []

            for idx, time_step in enumerate(times_sorted):
                bucket = per_time[time_step]
                bucket.sort(
                    key=lambda item: (item["intensity"], item["samples"]),
                    reverse=True,
                )

                quota = base_quota + (1 if idx < remainder else 0)
                if quota <= 0:
                    if bucket:
                        overflow.append((bucket, time_step))
                    continue

                take = min(len(bucket), quota)
                if take:
                    selected.extend(bucket[:take])
                if len(bucket) > take:
                    overflow.append((bucket[take:], time_step))

            current_total = len(selected)
            remaining = max_points - current_total
            if remaining > 0 and overflow:
                for bucket, _time_step in overflow:
                    if remaining <= 0:
                        break
                    if not bucket:
                        continue
                    take = min(len(bucket), remaining)
                    selected.extend(bucket[:take])
                    remaining -= take

            points = selected


    points.sort(key=lambda item: (item["time"], item["longitude"], item["latitude"]))

    stats = Stats()
    for point in points:
        stats.update(point["longitude"], point["latitude"])

    times_seen = {point["time"] for point in points}
    print(
        f"[heatmap] retained {stats.count} aggregated point(s) across "
        f"{len(times_seen)} timestep(s) from {path}. "
        f"(source buckets: {aggregated_count})"
    )
    return points


def load_polygons(path: Path) -> List[dict]:
    if not path.exists():
        return []

    features: List[dict] = []
    with path.open(newline="") as csvfile:
        reader = csv.DictReader(csvfile)
        if not reader.fieldnames:
            return []

        for row in reader:
            coords_raw = row.get("coordinates")
            if not coords_raw:
                continue
            try:
                coords = json.loads(coords_raw)
            except json.JSONDecodeError:
                continue

            if not isinstance(coords, list) or len(coords) < 4:
                # Need at least a closed ring (first == last)
                continue

            try:
                ring = [
                    [round(float(lon), 6), round(float(lat), 6)]
                    for lon, lat in coords
                ]
            except (TypeError, ValueError):
                continue

            if ring[0] != ring[-1]:
                ring.append(ring[0])

            feature = {
                "polygon_id": row.get("polygon_id"),
                "time": _to_int(row.get("time")) or 0,
                "area": _to_float(row.get("area")),
                "coordinates": ring,
            }
            features.append(feature)

    print(f"[polygons] retained {len(features)} features from {path}")
    return features


def write_payload(path: Path, points: Iterable[dict], polygons: Iterable[dict]) -> None:
    payload = {
        "points": list(points),
        "polygons": list(polygons),
    }
    times = sorted({point["time"] for point in payload["points"]})
    payload["timeSteps"] = times
    payload["generated"] = __package__ or "clean_heatmap"

    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as outfile:
        json.dump(payload, outfile, ensure_ascii=False)
        outfile.write("\n")

    print(f"[output] wrote JSON payload to {path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Clean flood CSV exports and emit a JSON payload for the UI."
    )
    parser.add_argument(
        "--heatmap",
        type=Path,
        default=DEFAULT_HEATMAP,
        help=f"Path to heatmap CSV (default: {DEFAULT_HEATMAP})",
    )
    parser.add_argument(
        "--polygons",
        type=Path,
        default=DEFAULT_POLYGONS,
        help=f"Path to dense polygons CSV (default: {DEFAULT_POLYGONS})",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help=f"Destination JSON path (default: {DEFAULT_OUTPUT})",
    )
    parser.add_argument(
        "--precision",
        type=int,
        default=4,
        help="Decimal places used when binning coordinates (default: 4).",
    )
    parser.add_argument(
        "--max-points",
        type=int,
        default=200000,
        help="Maximum aggregated points to retain (default: 200000).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    points = load_heatmap(args.heatmap, args.precision, args.max_points)
    polygons = load_polygons(args.polygons)
    write_payload(args.output, points, polygons)


if __name__ == "__main__":
    main()
