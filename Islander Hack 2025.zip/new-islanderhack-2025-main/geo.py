import geopandas as gpd

gdf = gpd.read_file("/Users/shaneciardelli/Programming/islanderhack_2025/islanderhack_2025/flood/flood.shp")

# Convert from EPSG:2279 → EPSG:4326 (lon/lat)
gdf = gdf.to_crs(epsg=4326)

# Check CRS
print(gdf.crs)

# Extract coordinates if needed
gdf["coords"] = gdf.geometry.apply(lambda geom: geom.__geo_interface__["coordinates"])

# Save to CSV with lat/lon polygons
gdf[["FLD_AR_ID", "FLD_ZONE", "coords"]].to_csv("flood_coords_latlon.csv", index=False)
