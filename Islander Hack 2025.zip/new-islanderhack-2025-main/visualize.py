import json
from pathlib import Path

import numpy as np
import pandas as pd
import folium
from folium.plugins import HeatMapWithTime

HEATMAP_FILE = "floodzones_heatmap.csv"
POLYGON_FILE = "dense_polygons.csv"


def load_heatmap(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(subset=["latitude", "longitude"])
    df["latitude"] = pd.to_numeric(df["latitude"], errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")
    df = df.dropna(subset=["latitude", "longitude"])
    return df


def build_frames(df: pd.DataFrame):
    frames = []
    for t in sorted(df["time"].unique()):
        frame = df[df["time"] == t][["latitude", "longitude", "intensity"]].values.tolist()
        frames.append(frame)
    return frames


def add_dense_polygons(map_obj: folium.Map, polygons_path: Path) -> int:
    if not polygons_path.exists():
        return 0

    df = pd.read_csv(polygons_path)
    if df.empty:
        return 0

    features = []
    for row in df.itertuples():
        try:
            coords = json.loads(row.coordinates)
        except json.JSONDecodeError:
            continue
        if len(coords) < 3:
            continue
        feature = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [coords],
            },
            "properties": {
                "polygon_id": getattr(row, "polygon_id", None),
                "time": getattr(row, "time", None),
                "area": getattr(row, "area", None),
            },
        }
        features.append(feature)

    if not features:
        return 0

    geo_json = {
        "type": "FeatureCollection",
        "features": features,
    }

    folium.GeoJson(
        geo_json,
        name="Dense Polygons",
        style_function=lambda _: {
            "fillColor": "#ff6600",
            "color": "#ff6600",
            "weight": 1,
            "fillOpacity": 0.25,
        },
        tooltip=folium.GeoJsonTooltip(
            fields=["polygon_id", "time", "area"],
            aliases=["Polygon", "Time", "Area"],
            localize=True,
        ),
    ).add_to(map_obj)

    return len(features)


def main() -> None:
    df = load_heatmap(HEATMAP_FILE)

    print(f"✅ Loaded {len(df)} valid points")
    print(f"Latitude range: {df['latitude'].min():.4f} → {df['latitude'].max():.4f}")
    print(f"Longitude range: {df['longitude'].min():.4f} → {df['longitude'].max():.4f}")

    frames = build_frames(df)

    center_lat = df["latitude"].mean()
    center_lon = df["longitude"].mean()

    m = folium.Map(location=[center_lat, center_lon], zoom_start=12)

    HeatMapWithTime(
        data=frames,
        radius=10,
        blur=0.75,
        min_opacity=0.15,
        max_opacity=0.85,
        use_local_extrema=False,
        auto_play=True,
        display_index=True,
    ).add_to(m)

    polygon_count = add_dense_polygons(m, Path(POLYGON_FILE))
    if polygon_count:
        print(f"✅ Overlayed {polygon_count} dense polygons from {POLYGON_FILE}")
    else:
        print("ℹ️  No dense polygons overlayed (file missing or empty).")

    m.save("animated_heatmap.html")
    print("✅ Saved: animated_heatmap.html — open it in your browser.")


if __name__ == "__main__":
    main()
